public enum Course {
    LEI, LECI, LEEC
}
