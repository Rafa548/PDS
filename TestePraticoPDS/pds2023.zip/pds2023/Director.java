public class Director {
    private Course degreeName;

    public Director (StudentAdm stud, Course course) {
        this.degreeName = course;
        // ...
    }

    public Course getCourseName() {
        return degreeName;
    }

}
