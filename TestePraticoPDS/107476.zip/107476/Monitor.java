public abstract class Monitor {
        protected StudentAdm adm;
        public abstract void update(StudentAdm adm);
        public abstract String getType();
        public abstract String getClassName();
}
